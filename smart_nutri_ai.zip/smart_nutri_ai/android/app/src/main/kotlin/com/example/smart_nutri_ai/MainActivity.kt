package com.example.smart_nutri_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}