plugins {
    id("com.android.application")
    id("kotlin-android")
    // حذفنا السطر اللي يسبب المشكلة واستبدلناه بالتعريف المباشر بالأسفل
}

android {
    namespace = "com.example.smart_nutri_ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.smart_nutri_ai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

// تعريف فلاتر اليدوي لضمان التشغيل
apply(from = "${rootProject.projectDir}/../local.properties")
val flutterRoot = project.property("flutter.sdk").toString()
apply(from = "$flutterRoot/packages/flutter_tools/gradle/flutter.gradle")