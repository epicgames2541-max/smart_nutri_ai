import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MealManager extends ChangeNotifier {
  static final MealManager _instance = MealManager._internal();
  factory MealManager() => _instance;
  MealManager._internal() {
    loadData();
  }

  int consumedCalories = 0;
  int consumedProtein = 0;
  int consumedCarbs = 0;
  int consumedFat = 0;

  // سجل السعرات لآخر 7 أيام (بيانات وهمية للتجربة + تخزين حقيقي)
  List<double> weeklyHistory = [2100, 1800, 2500, 1900, 2800, 2200, 0]; 

  Future<void> loadData() async {
    final prefs = await SharedPreferences.getInstance();
    consumedCalories = prefs.getInt('cal') ?? 0;
    consumedProtein = prefs.getInt('prot') ?? 0;
    consumedCarbs = prefs.getInt('carb') ?? 0;
    consumedFat = prefs.getInt('fat') ?? 0;
    
    // تحديث رقم اليوم الحالي في السجل الأسبوعي
    weeklyHistory[6] = consumedCalories.toDouble();
    notifyListeners();
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('cal', consumedCalories);
    await prefs.setInt('prot', consumedProtein);
    await prefs.setInt('carb', consumedCarbs);
    await prefs.setInt('fat', consumedFat);
  }

  void addMeal(int cal, int prot, int carb, int fat) {
    consumedCalories += cal;
    consumedProtein += prot;
    consumedCarbs += carb;
    consumedFat += fat;
    weeklyHistory[6] = consumedCalories.toDouble(); // تحديث الرسم البياني لحظياً
    _saveData();
    notifyListeners();
  }

  void reset() {
    consumedCalories = 0;
    consumedProtein = 0;
    consumedCarbs = 0;
    consumedFat = 0;
    weeklyHistory[6] = 0;
    _saveData();
    notifyListeners();
  }
}