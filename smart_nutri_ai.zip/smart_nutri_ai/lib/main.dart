import 'package:flutter/material.dart';
import 'screens/splash_screen.dart'; 
import 'notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await NotificationService.init();
  } catch (e) {
    print("Notification Init Error: $e");
  }
  runApp(const SmartNutriAI());
}

class SmartNutriAI extends StatelessWidget {
  const SmartNutriAI({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Nutri AI',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF00FF88),
        scaffoldBackgroundColor: const Color(0xFF0A0A0A),
      ),
      home: const SplashScreen(),
    );
  }
}