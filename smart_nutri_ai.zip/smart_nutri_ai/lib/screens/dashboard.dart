import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../meal_manager.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final MealManager manager = MealManager();

  @override
  void initState() {
    super.initState();
    manager.addListener(_updateUI);
  }

  @override
  void dispose() {
    manager.removeListener(_updateUI);
    super.dispose();
  }

  void _updateUI() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("تحليلات الأداء")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _buildAnimatedCounter(),
            const SizedBox(height: 30),
            
            const Align(
              alignment: Alignment.centerRight,
              child: Text("التزامك الأسبوعي (KCAL)", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 15),
            
            // الرسم البياني الأسبوعي
            _buildWeeklyChart(),
            
            const SizedBox(height: 30),
            _buildMacroProgress("البروتين", manager.consumedProtein, 150, Colors.greenAccent),
            _buildMacroProgress("الكاربوهيدرات", manager.consumedCarbs, 300, Colors.blueAccent),
            _buildMacroProgress("الدهون", manager.consumedFat, 70, Colors.redAccent),
          ],
        ),
      ),
    );
  }

  Widget _buildWeeklyChart() {
    return Container(
      height: 180,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(25),
      ),
      child: BarChart(
        BarChartData(
          gridData: const FlGridData(show: false),
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: false),
          barGroups: manager.weeklyHistory.asMap().entries.map((e) {
            return BarChartGroupData(
              x: e.key,
              barRods: [
                BarChartRodData(
                  toY: e.value,
                  color: e.key == 6 ? const Color(0xFF00FF88) : Colors.white24,
                  width: 18,
                  borderRadius: BorderRadius.circular(4),
                )
              ],
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildAnimatedCounter() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(35),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0xFF00FF88).withOpacity(0.2)),
      ),
      child: Column(
        children: [
          const Text("مجموع السعرات اليوم", style: TextStyle(color: Colors.grey)),
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: manager.consumedCalories.toDouble()),
            duration: const Duration(seconds: 1),
            builder: (context, value, child) {
              return Text("${value.toInt()}", style: const TextStyle(fontSize: 55, fontWeight: FontWeight.bold, color: Color(0xFF00FF88)));
            },
          ),
        ],
      ),
    );
  }

  Widget _buildMacroProgress(String title, int current, int goal, Color color) {
    double progress = (current / goal).clamp(0.0, 1.0);
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [Text(title), Text("$current / $goal g", style: TextStyle(color: color))],
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: progress, backgroundColor: Colors.white10, color: color, minHeight: 8),
        ],
      ),
    );
  }
}