import 'package:flutter/material.dart';
import 'dart:async';

class AIScannerScreen extends StatefulWidget {
  const AIScannerScreen({super.key});

  @override
  State<AIScannerScreen> createState() => _AIScannerScreenState();
}

class _AIScannerScreenState extends State<AIScannerScreen> with SingleTickerProviderStateMixin {
  bool isScanning = false;
  bool scanComplete = false;
  late AnimationController _animController;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  void startScan() {
    setState(() {
      isScanning = true;
      scanComplete = false;
    });
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          isScanning = false;
          scanComplete = true;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("المحلل الذكي 🤖"), backgroundColor: Colors.transparent, elevation: 0),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: startScan,
              child: Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  color: Colors.black,
                  border: Border.all(color: isScanning ? const Color(0xFF00FF88) : Colors.grey, width: 3),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: isScanning ? [BoxShadow(color: const Color(0xFF00FF88).withOpacity(0.5), blurRadius: 30)] : [],
                ),
                child: isScanning
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const CircularProgressIndicator(color: Color(0xFF00FF88)),
                          const SizedBox(height: 20),
                          AnimatedBuilder(
                            animation: _animController,
                            builder: (context, child) => Opacity(
                              opacity: _animController.value,
                              child: const Text("جاري تحليل الوجبة...", style: TextStyle(color: Color(0xFF00FF88))),
                            ),
                          ),
                        ],
                      )
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.camera_alt_rounded, size: 80, color: Colors.grey),
                          SizedBox(height: 10),
                          Text("اضغط لفتح الكاميرا", style: TextStyle(color: Colors.grey)),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 40),
            if (scanComplete) _buildAIResultCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildAIResultCard() {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Row(
              children: [
                Icon(Icons.auto_awesome, color: Colors.amber),
                SizedBox(width: 10),
                Text("نتيجة التحليل الذكي", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            const Divider(color: Colors.grey),
            const ListTile(
              title: Text("دجاج مشوي مع أرز أبيض", style: TextStyle(fontSize: 20, color: Color(0xFF00FF88))),
              subtitle: Text("نسبة الدقة: 98%"),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _macroBadge("السعرات", "450", Colors.white),
                _macroBadge("البروتين", "40g", Colors.blueAccent),
                _macroBadge("الكارب", "45g", Colors.orangeAccent),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00FF88), foregroundColor: Colors.black),
              onPressed: () {},
              child: const Text("إضافة لليوميات"),
            )
          ],
        ),
      ),
    );
  }

  Widget _macroBadge(String label, String val, Color color) {
    return Column(
      children: [
        Text(val, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }
}