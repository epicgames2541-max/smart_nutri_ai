import 'package:flutter/material.dart';
import '../models/meal_data.dart';
import '../models/recipe.dart';
import '../meal_manager.dart';

class RecipeDatabaseScreen extends StatefulWidget {
  const RecipeDatabaseScreen({super.key});

  @override
  State<RecipeDatabaseScreen> createState() => _RecipeDatabaseScreenState();
}

class _RecipeDatabaseScreenState extends State<RecipeDatabaseScreen> {
  final List<Recipe> allRecipes = MealData.generateMassiveData();
  String selectedCategory = "الكل";
  final List<String> categories = ["الكل", "فطور", "غداء", "عشاء", "سناك"];

  @override
  Widget build(BuildContext context) {
    // تصفية القائمة بناءً على الخيار المختار
    List<Recipe> filteredRecipes = selectedCategory == "الكل" 
        ? allRecipes 
        : allRecipes.where((r) => r.category == selectedCategory).toList();

    return Scaffold(
      appBar: AppBar(title: const Text("مطبخ حسن الذكي")),
      body: Column(
        children: [
          // شريط التصنيفات
          Container(
            height: 60,
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              itemBuilder: (context, index) {
                bool isSelected = selectedCategory == categories[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: ChoiceChip(
                    label: Text(categories[index]),
                    selected: isSelected,
                    selectedColor: const Color(0xFF00FF88),
                    onSelected: (val) => setState(() => selectedCategory = categories[index]),
                  ),
                );
              },
            ),
          ),
          
          // القائمة المصفاة
          Expanded(
            child: ListView.builder(
              itemCount: filteredRecipes.length,
              itemBuilder: (context, index) {
                final recipe = filteredRecipes[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                  child: ExpansionTile(
                    title: Text(recipe.name),
                    subtitle: Text("${recipe.calories} سعرة | ${recipe.category}"),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(15),
                        child: ElevatedButton(
                          onPressed: () {
                            MealManager().addMeal(recipe.calories, 30, 40, 10);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("تمت الإضافة بنجاح!"))
                            );
                          },
                          child: const Text("إضافة ليومي"),
                        ),
                      )
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}