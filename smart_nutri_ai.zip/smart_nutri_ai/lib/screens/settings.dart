import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  double weight = 75;
  double height = 175;
  String selectedGoal = "تنشيف";

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      weight = prefs.getDouble('weight') ?? 75;
      height = prefs.getDouble('height') ?? 175;
      selectedGoal = prefs.getString('goal') ?? "تنشيف";
    });
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('weight', weight);
    await prefs.setDouble('height', height);
    await prefs.setString('goal', selectedGoal);
  }

  // دالة حساب كتلة الجسم (BMI)
  String getBMIStatus() {
    double bmi = weight / ((height / 100) * (height / 100));
    if (bmi < 18.5) return "نقص وزن - تحتاج تضخيم 🦴";
    if (bmi < 25) return "وزن مثالي - وحش يا حسن! 🦾";
    return "زيادة وزن - وقت التنشيف 🔥";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("الملف الشخصي")),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // كارت الحالة الذكي
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF151515),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF00FF88).withOpacity(0.3)),
            ),
            child: Column(
              children: [
                const Text("تحليل الحالة الذكي", style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 10),
                Text(getBMIStatus(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF00FF88))),
              ],
            ),
          ),
          const SizedBox(height: 30),
          _buildGoalSelector(),
          _buildSlider("الوزن (كجم)", weight, 40, 150, (v) => setState(() { weight = v; _saveData(); })),
          _buildSlider("الطول (سم)", height, 140, 220, (v) => setState(() { height = v; _saveData(); })),
        ],
      ),
    );
  }

  Widget _buildGoalSelector() {
    return ListTile(
      title: const Text("هدفك الحالي"),
      trailing: DropdownButton<String>(
        value: selectedGoal,
        items: ["تنشيف", "تضخيم", "تخسيس"].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() { selectedGoal = v!; _saveData(); }),
      ),
    );
  }

  Widget _buildSlider(String label, double val, double min, double max, Function(double) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("$label: ${val.toInt()}"),
        Slider(value: val, min: min, max: max, activeColor: const Color(0xFF00FF88), onChanged: onChanged),
      ],
    );
  }
}