import 'package:flutter/material.dart';
import 'dashboard.dart';
import 'ai_scanner.dart';
import 'recipes_screen.dart';
import 'settings.dart';
import 'challenge_screen.dart'; // استدعاء الملف الجديد

class MainAppController extends StatefulWidget {
  const MainAppController({super.key});

  @override
  State<MainAppController> createState() => _MainAppControllerState();
}

class _MainAppControllerState extends State<MainAppController> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const DashboardScreen(),
    const AIScannerScreen(),
    const ChallengeScreen(), // وضعنا التحدي في المنتصف للتشجيع
    const RecipeDatabaseScreen(),
    const SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        selectedItemColor: const Color(0xFF00FF88),
        unselectedItemColor: Colors.grey,
        backgroundColor: Colors.black,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: "الرئيسية"),
          BottomNavigationBarItem(icon: Icon(Icons.camera_alt_rounded), label: "الماسح"),
          BottomNavigationBarItem(icon: Icon(Icons.emoji_events_rounded), label: "التحدي"),
          BottomNavigationBarItem(icon: Icon(Icons.restaurant_menu_rounded), label: "الوصفات"),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: "حسابي"),
        ],
      ),
    );
  }
}