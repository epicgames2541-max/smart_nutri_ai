import 'package:flutter/material.dart';
import 'dart:async';
import 'main_controller.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // الانتقال للتطبيق بعد 3 ثوانٍ
    Timer(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MainAppController()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // أيقونة التطبيق مع أنميشن بسيط
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0.0, end: 1.0),
              duration: const Duration(seconds: 2),
              builder: (context, value, child) {
                return Opacity(
                  opacity: value,
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: const Color(0xFF00FF88), width: 2),
                    ),
                    child: const Icon(Icons.bolt, size: 80, color: Color(0xFF00FF88)),
                  ),
                );
              },
            ),
            const SizedBox(height: 30),
            const Text(
              "Smart Nutri AI",
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 10),
            const Text("بإشراف الكابتن حسن 🦾", style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 50),
            const CircularProgressIndicator(color: Color(0xFF00FF88)),
          ],
        ),
      ),
    );
  }
}