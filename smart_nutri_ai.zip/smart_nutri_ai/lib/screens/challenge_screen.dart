import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChallengeScreen extends StatefulWidget {
  const ChallengeScreen({super.key});

  @override
  State<ChallengeScreen> createState() => _ChallengeScreenState();
}

class _ChallengeScreenState extends State<ChallengeScreen> {
  // قائمة بـ 30 يوم (false تعني لم يكتمل، true تعني اكتمل)
  List<bool> challengeDays = List.generate(30, (index) => false);

  @override
  void initState() {
    super.initState();
    _loadChallengeProgress();
  }

  // تحميل تقدم التحدي من ذاكرة الهاتف
  Future<void> _loadChallengeProgress() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      for (int i = 0; i < 30; i++) {
        challengeDays[i] = prefs.getBool('day_$i') ?? false;
      }
    });
  }

  // حفظ اليوم الذي تم إنجازه
  Future<void> _toggleDay(int index) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      challengeDays[index] = !challengeDays[index];
      prefs.setBool('day_$index', challengeDays[index]);
    });
  }

  @override
  Widget build(BuildContext context) {
    int completedCount = challengeDays.where((day) => day).length;

    return Scaffold(
      appBar: AppBar(title: const Text("تحدي الـ 30 يوم 🏆")),
      body: Column(
        children: [
          _buildProgressHeader(completedCount),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 5, // 5 أيام في كل صف
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: 30,
              itemBuilder: (context, index) {
                bool isDone = challengeDays[index];
                return GestureDetector(
                  onTap: () => _toggleDay(index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    decoration: BoxDecoration(
                      color: isDone ? const Color(0xFF00FF88) : const Color(0xFF1A1A1A),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: isDone ? Colors.white : Colors.white10,
                        width: 2,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        "${index + 1}",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: isDone ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressHeader(int completed) {
    double percent = completed / 30;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(25),
      margin: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(25),
      ),
      child: Column(
        children: [
          const Text("مستوى الإنجاز", style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: percent,
            backgroundColor: Colors.white10,
            color: const Color(0xFF00FF88),
            minHeight: 10,
          ),
          const SizedBox(height: 10),
          Text(
            "$completed من 30 يوم مكتمل",
            style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF00FF88)),
          ),
        ],
      ),
    );
  }
}