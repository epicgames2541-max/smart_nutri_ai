class Recipe {
  final String name;
  final int calories;
  final String protein;
  final List<String> ingredients;
  final List<String> steps;
  final String category; // النوع: فطور، غداء، إلخ..

  Recipe(this.name, this.calories, this.protein, this.ingredients, this.steps, {this.category = "غداء"});
}